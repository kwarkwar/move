<?php

if (!defined('RAPIDLEECH')) {
	require_once('index.html');
	exit;
}

class openload_co extends DownloadClass {
	private $page, $cookie = array(), $elink, $pA, $DLRegexp = '@https?://\w+\.(?:openload\.co|oloadcdn\.net)/dl/[^\t\r\n\'\"<>\?]+@i';
	public function Download($link) {
$flink = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$cdnlink =  "http://api.fastrapidleech.com/cdn.php";
$apilink = "http://api.fastrapidleech.com/openload.php";
echo "<br><br>";
 if(isset($_POST['Openload_Key_Found']) && !empty($_POST['key']))
{
$url = $_POST['link'];
$key = $_POST['key'];
$name = $_POST['file_name'];
$data = array();
$data["key"] = $key ;
$data["flink"] = $flink ;
$cdn_link = $cdnlink . '?flink=' . $flink ; 
$this->RedirectDownload($cdn_link, $name, 0, $data);
exit();
}
if (!preg_match('@https?://openload\.co/f/([\w-]+)@i', str_ireplace(array('://www.openload.co', '/embed/'), array('://openload.co', '/f/'), $link), $fid)) html_error('Invalid link?.');
$fid = $fid[1];
        $api_key = 'highendserver';
        $token_id = '52100312';
        $ticket_id = '52100832';
        $link = str_replace('http://', 'https://', $link);
        $page = $this->GetPage($link);
        if (!preg_match('%streamurl%', $page, $tmp)) html_error('Download Link Not Available!! #27x001');
        $postdata = http_build_query(
    array(
        'flink' => $flink,
        'fid' => $fid
    )
);
$opts = array('http' =>
    array(
        'method'  => 'POST',
        'header'  => 'Content-type: application/x-www-form-urlencoded',
        'content' => $postdata
    )
);
$context  = stream_context_create($opts);
$api_link = $apilink . '?flink=' . $flink ; 
$result = file_get_contents($api_link, false, $context);
$output = json_decode($result,1);
$status = $output["status"] ;
$msg = $output["msg"];
if( $status === 'NO') html_error($msg);
if( $status === 'OK') echo $output["page"];
exit();
	}

}


//[26-06-2017]  Written by  - FastRapidleech.Com (fastrapidleech@gmail.com)

?>