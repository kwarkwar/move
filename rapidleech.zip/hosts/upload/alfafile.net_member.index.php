<?php
$upload_services[] = 'alfafile.net_member';
$max_file_size['alfafile.net_member'] = false;
$page_upload['alfafile.net_member'] = 'alfafile.net_member.php';  
?>