<?php
$upload_services[] = 'multiup.org';
$max_file_size['multiup.org'] = 5120;
$page_upload['multiup.org'] = 'multiup.org.php';  
?>