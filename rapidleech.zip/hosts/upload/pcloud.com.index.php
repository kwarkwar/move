<?php
$upload_services[] = 'pcloud.com';
$max_file_size['pcloud.com'] = 20000;
$page_upload['pcloud.com'] = 'pcloud.com.php';
?>
