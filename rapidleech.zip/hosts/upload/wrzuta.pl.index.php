<?php
$upload_services[] = "wrzuta.pl";
$max_file_size["wrzuta.pl"] = 500;
$page_upload["wrzuta.pl"] = "wrzuta.pl.php";
?>